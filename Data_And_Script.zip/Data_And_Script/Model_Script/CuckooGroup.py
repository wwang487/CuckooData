from Cuckoo import *
from CuckooEgg import *
import random
import math
from ReedsBirdPair import *
from ReedsBirdGroup import *
from ReedsBirdGroups import *
from ParasiteRand import *

class CuckooGroup:
    
    
    def __init__(self, Female_Cuckoo, Male_Cuckoo, spe_name, choice):
        self.Female_Cuckoo = Female_Cuckoo
        self.Male_Cuckoo = Male_Cuckoo
        self.spe_name = spe_name
        self.mating_coef = 0.95
        
        self.choice = choice
        self.sigma_1 = 0.1
        self.sigma_2 = 1
        self.l_low = 0
        self.l_high = 4
        self.s0 = 1
        self.coef = 5
        self.ReedsBird_s = ReedsBirdGroups({})
    
    def PassingCuckooGroupParams(self, val_1, val_2, val_3, val_4):
        self.sigma_1 = val_1
        self.sigma_2 = val_2
        self.l_low = val_3
        self.l_high = val_4
    
    def PassingCuckooNaturalVar(self, s0):
        self.s0 = s0
    
    def getCuckooChoice(self):
        return self.choice
    
    def setCuckooChoice(self, val):
        self.choice = val
    
    def getFemaleCuckooNum(self):
        if not self.Female_Cuckoo:
            return 0
        return len(self.Female_Cuckoo)
    
    def getMaleCuckooNum(self):
        if not self.Male_Cuckoo:
            return 0
        return len(self.Male_Cuckoo)
    
    def getTotalCuckooEggNum(self):
        count = 0
        for i in self.Female_Cuckoo:
            count += i.getCuckooEggNum()
        return count
    
    def getUpdatedReedsBird(self):
        return self.ReedsBird_s 
    
    def setCuckooGroupSpeName(self, val):
        self.spe_name = val
        
    def getCuckooGroupSpeName(self):
        return self.spe_name
    
    def getTotalCuckooNum(self):
        return self.getFemaleCuckooNum() +self.getMaleCuckooNum()
    
    def setCuckooGroupMatingRate(self, P):
        self.mating_coef = P
        
    def getCuckooGroupMatingRate(self):
        return self.mating_coef
    
    def addFemaleCuckoo(self, female_cuckoo):
        self.Female_Cuckoo.append(female_cuckoo)
    
    def addMaleCuckoo(self, male_cuckoo):
        self.Male_Cuckoo.append(male_cuckoo)
        
    def getPregFemaleCuckooNum(self):
        return math.floor(self.getFemaleCuckooNum() * self.mating_coef)
    
    def getFemaleCuckoo(self):
        return self.Female_Cuckoo
    
    def getMaleCuckoo(self):
        return self.Male_Cuckoo
    
    def markPregFemaleCuckoo(self):
        Preg_Num = self.getPregFemaleCuckooNum()
        random.shuffle(self.Female_Cuckoo)
        for i in range(Preg_Num):
            self.Female_Cuckoo[i].setPregCond(True)
                    
    def resetPregFemaleCuckoo(self):
        Female_Num = self.getFemaleCuckooNum()
        for i in range(Female_Num):
            self.Female_Cuckoo[i].setPregCond(False)
    
    def addOneAge2Cuckoo(self):
        Female_Num = self.getFemaleCuckooNum()
        Male_Num = self.getMaleCuckooNum()
        for i in range(Female_Num):
            self.Female_Cuckoo[i].growCuckoo()
        for i in range(Male_Num):
            self.Male_Cuckoo[i].growCuckoo()
    
    def RemoveDeadCuckoo(self):
        Female_Num = self.getFemaleCuckooNum()
        Male_Num = self.getMaleCuckooNum()
        f0 = Female_Num - 1
        m0 = Male_Num - 1
        while f0 >= 0:
            if self.Female_Cuckoo[f0].isCuckooDead():
                self.Female_Cuckoo.pop(f0)
            f0 = f0 - 1        
        while m0 >= 0:
            if self.Male_Cuckoo[m0].isCuckooDead():
                self.Male_Cuckoo.pop(m0)
            m0 = m0 - 1
            
    def getBabyMaleCuckooPopulation(self):
        count = 0
        Male_Num = self.getMaleCuckooNum()
        for i in range(Male_Num):
            if self.Male_Cuckoo[i].getCuckcooAge() == 0:
                count = count + 1
        return count
    
    def getBabyFemaleCuckooPopulation(self):
        count = 0
        Female_Num = self.getFemaleCuckooNum()
        for i in range(Female_Num):
            if self.Female_Cuckoo[i].getCuckcooAge() == 0:
                count = count + 1
        return count
    
    def CuckooAfterBadEnvSce(self):
        if self.s0 == 0:
            Female_Num = self.getFemaleCuckooNum()
            Male_Num = self.getMaleCuckooNum()
            Rev_Female_Num = math.floor(Female_Num / self.coef)
            Rev_Male_Num = math.floor(Male_Num / self.coef)
            while Rev_Female_Num > 0:
                female_ind = random.randint(0, Rev_Female_Num)
                self.Female_Cuckoo.pop(female_ind)
                Rev_Female_Num = Rev_Female_Num - 1
            while Rev_Male_Num > 0:
                male_ind = random.randint(0, Rev_Male_Num)
                self.Female_Cuckoo.pop(male_ind)
                Rev_Male_Num = Rev_Male_Num - 1
    
    def CuckooFirstGaming(self):
        if self.getTotalCuckooNum() != 0:
            self.markPregFemaleCuckoo()
            Female_Num = self.getFemaleCuckooNum()
            Male_Num = self.getMaleCuckooNum()
            if Male_Num == 0:
                self.resetPregFemaleCuckoo()
                self.addOneAge2Cuckoo()
                return
            for i in range(Female_Num):
                if self.Female_Cuckoo[i].getPregCond():
                    male_ind = random.randint(0, Male_Num - 1)
                    temp_egg = CuckooEgg(self.Female_Cuckoo[i],self.Male_Cuckoo[male_ind])
                    temp_egg.passCuckooGroupCoef(self.l_low, self.l_high, self.sigma_1, self.sigma_2)
                    self.Female_Cuckoo[i].apprendOneEgg(temp_egg)
            self.addOneAge2Cuckoo()
        
    def CuckooSecondGaming(self, Reedsbirds):
        if self.getTotalCuckooNum() != 0:
            Female_Num = self.getFemaleCuckooNum()
            for i in range(Female_Num):
                temp_cuckoo = self.Female_Cuckoo[i]
                if temp_cuckoo.getPregCond():
                    Laid_atleast_One = False
                    Remain_mom_Nest_num = Reedsbirds.getReedsBirds().get(temp_cuckoo.getdefaultmom())\
                                          .getNonOccupiedReedsBirdPairNum()
                    
                    Cuckoo_Eggs = temp_cuckoo.getFemaleCuckooEggs()
                    
                    for j in Cuckoo_Eggs:
                        temp_key = temp_cuckoo.getdefaultmom() if Remain_mom_Nest_num > 0 else Reedsbirds.selectrandomkey()                  
                        Remain_Nest_Num = Remain_mom_Nest_num if Remain_mom_Nest_num > 0 else Reedsbirds.getReedsBirds().get(temp_key).getNonOccupiedReedsBirdPairNum()
                        if Remain_Nest_Num == 0:
                            break
                        elif Remain_mom_Nest_num == 0 and not self.choice:
                            continue
                        elif Remain_mom_Nest_num == 0:
                            j.UpdateDefaultMom(temp_key)
                        ind = random.randrange(Remain_Nest_Num)
                        LaidProb = temp_cuckoo.getCuckooActLaidProb() - Reedsbirds.getReedsBirds().get(temp_key).getSigNonOccupiedReedsBirdPair(ind).getReedsBirdPairStayProb()
                        if IsReallyLaid(LaidProb):
                            Laid_atleast_One = True
                            ind = random.randrange(Remain_Nest_Num)
                            Reedsbirds.ReedsBirds[temp_key].updateNonOccupiedReedsBirdPairs(ind, j)
                            if Remain_mom_Nest_num > 0:
                                Remain_mom_Nest_num -= 1
                    if Laid_atleast_One:
                        self.Female_Cuckoo[i].UpdateFemaleCuckooLaid()
            self.ReedsBird_s = Reedsbirds
    
    def CuckooFinalGaming(self, baby_male, baby_female):
        if self.getTotalCuckooNum() != 0:
            for bm in baby_male:
                Baby_Male_Num = 0 if not bm else len(bm)
                for i in range(Baby_Male_Num):
                    
                    if bm[i].getCuckooSpeName() == self.spe_name:
                        self.Male_Cuckoo.append(bm[i])
            for bf in baby_female:
                Baby_Female_Num = 0 if not bf else len(bf)
                for i in range(Baby_Female_Num):
                    
                    if bf[i].getCuckooSpeName() == self.spe_name:
                        self.Female_Cuckoo.append(bf[i])
            self.RemoveDeadCuckoo()
            self.resetPregFemaleCuckoo()
    
    def getAverTotalCheatingReinFac(self):
        Female_Num = self.getFemaleCuckooNum()
        Prob_sum = 0
        for i in range(Female_Num):
            Prob_sum = Prob_sum + self.Female_Cuckoo[i].getTotalCuckooReinFac()
        res = Prob_sum/Female_Num if Female_Num > 0 else 0
        return res
    
    def countCuckooProp(self):
        Female_Num = self.getFemaleCuckooNum()
        Male_Num = self.getMaleCuckooNum()
        Total_Num = self.getTotalCuckooNum()
        New_Female_Num = self.getBabyFemaleCuckooPopulation()
        New_Male_Num = self.getBabyMaleCuckooPopulation()
        res = [Female_Num, Male_Num, Total_Num, New_Female_Num, New_Male_Num, self.getAverTotalCheatingReinFac()]
        return res