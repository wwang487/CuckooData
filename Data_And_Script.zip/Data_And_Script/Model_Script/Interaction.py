from Cuckoo import *
from CuckooGroup import *
from CuckooGroups import *
from ReedsBird import *
from ReedsBirdPair import *
from ReedsBirdGroup import *
from ReedsBirdGroups import *
from ReadSpeData import *
import numpy
import numpy as np
import random
import math
import matplotlib.pyplot as plt
import argparse
import os

parser = argparse.ArgumentParser(description = 'Environment Settings', formatter_class = argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('-c', '--cuckoopath', dest = 'cuckoopath', type = str, default = 'D:/CUCKOO/Cuckoo/',
                        help='Path to where the cuckoo file is saved')
parser.add_argument('-r', '--reedspath', dest = 'reedspath', type = str, default = 'D:/CUCKOO/Reeds/',
                        help='Path to where the reeds file is saved')
parser.add_argument('-o', '--outpath', dest = 'outpath', type = str, default = 'D:/CUCKOO/OUT/',
                        help='Path to where the OUTPUT file is saved')

parser.add_argument('-c1', '--cuckoofile', dest = 'cuckoofile', type = str, default = 'Cuckoo_12.csv',
                        help='cuckoo file name')
parser.add_argument('-r1', '--reedsfile', dest = 'reedsfile', type = str, default = 'ReedsBird_1.csv',
                        help='reeds file name')

parser.add_argument('-q', '--question', dest = 'question', type = str, default = 'a',
                        help='do question 1 or 2')

parser.add_argument('-d', '--delta', dest = 'delta', type = float, default = 0.05,
                        help='prob interval in simulation')

parser.add_argument('-lc', '--c_list', dest = 'c_list', nargs='+', type=int)

parser.add_argument('-ls', '--s_list', dest = 's_list', nargs='+', type=int)

parser.add_argument('-g', '--gap', dest = 'gap', type = float, default =  0.3,
                        help='Val of Init Gap')

parser.add_argument('-ch', '--choice', dest = 'choice', type = str, default = "t", help = 'Is cuckoo re-select')
parser.add_argument('-s1', '--sigma1', dest = 'sigma1', type = float, default = 0.02, help = 'sigma for cuckoo_cont')
parser.add_argument('-s2', '--sigma2', dest = 'sigma2', type = float, default = 1, help = 'sigma for cuckoo_discrete')
parser.add_argument('-s3', '--sigma3', dest = 'sigma3', type = float, default = 0.02, help = 'sigma for reeds_cont')
parser.add_argument('-s4', '--sigma4', dest = 'sigma4', type = float, default = 1, help = 'sigma for reeds _discrete')

parser.add_argument('-N', '--years', dest = 'years', type = int, default = 300, help = 'number of years')
parser.add_argument('-M', '--iter', dest = 'iter', type = int, default = 10, help = 'number of simulations')
parser.add_argument('-P', '--penalty', dest = 'penalty', type =float, default = 0.9, help = 'penalty coef of crowding')

args = parser.parse_args()
cuckoo_choice = True if args.choice == 't' else False
sigma_1 = args.sigma1
sigma_2 = args.sigma2
sigma_3 = args.sigma3
sigma_4 = args.sigma4
Y = args.years
Pel = args.penalty
M = args.iter
cuckoo_dir = args.cuckoopath + args.cuckoofile
reeds_dir = args.reedspath + args.reedsfile
simu_type = args.question
delta_test = args.delta
out_dir = args.outpath + args.cuckoofile.split('.')[0] +  '_' + args.reedsfile.split('.')[0] + '_' + simu_type

if cuckoo_choice:
    out_dir = out_dir + '_tr'
else:
    out_dir = out_dir + '_fl'

def CheckIfFolderExist(suffix):
    if os.path.exists(f'{out_dir}{suffix}'):
        pass
    else:
        os.mkdir(f'{out_dir}{suffix}')

CheckIfFolderExist('')

def CalOrdersFeat(val):
    range_len = min(1, val + args.gap) - max(0, val - args.gap)
    num = int(range_len // delta_test)
    return num, min(1, val + args.gap), max(0, val - args.gap)

def getInitialCuckooVals(Cuckoo_set):
    count = 0
    for key in Cuckoo_set.keys():  
        val_c = float(Cuckoo_set.get(key).get('PROB_C'))
        val_s = float(Cuckoo_set.get(key).get('PROB_S'))
        num_c, high_c, low_c = CalOrdersFeat(val_c)
        num_s, high_s, low_s = CalOrdersFeat(val_s)
        count = count + 1
        if count > 0:
            break
    return num_c, low_c, high_c, num_s, low_s, high_s

def CreateInitialCuckoos(Cuckoo_set, Reeds_set):
    Cuckoos = {}
    Life_c_l = {}
    Life_c_r = {}
    for key in Cuckoo_set.keys():        
        spe_name = Cuckoo_set.get(key).get('SPE_NAME')
        temp_c = CuckooGroup([],[], spe_name, cuckoo_choice)
        cuckoo_p_hatch = float(Cuckoo_set.get(key).get('PROB_ALIVE_EGG'))
        cuckoo_life_low = int(Cuckoo_set.get(key).get('LIFE_LOW'))
        cuckoo_life_high = int(Cuckoo_set.get(key).get('LIFE_HIGH'))
        cuckoo_life_m = float(Cuckoo_set.get(key).get('LIFE_M'))
        cuckoo_prob_lay = float(Cuckoo_set.get(key).get('PROB_LAY'))
        cuckoo_d_prob_l = float(Cuckoo_set.get(key).get('D_PROB_L'))
        cuckoo_prob_c = float(Cuckoo_set.get(key).get('PROB_C'))
        cuckoo_prob_s = float(Cuckoo_set.get(key).get('PROB_S'))
        cuckoo_egg_n = int(Cuckoo_set.get(key).get('EGG_N'))
        cuckoo_mom_n = int(Cuckoo_set.get(key).get('MOM_N'))
        cuckoo_pop_n = int(Cuckoo_set.get(key).get('POP_N'))
        mom_set = random.sample(Reeds_set.keys(), cuckoo_mom_n)
        for i in range(cuckoo_pop_n):
            life_C = round(genWeibullSampleValue(cuckoo_life_m, sigma_2, cuckoo_life_low, cuckoo_life_high))
            age_C = math.floor(numpy.random.uniform(0, life_C))
            
            c_p_h = genNormalSampleValue(cuckoo_p_hatch, sigma_1, 0, 1)
            c_p_l = genNormalSampleValue(cuckoo_prob_lay, sigma_1, 0, 1)
            c_d_p_l = genNormalSampleValue(cuckoo_d_prob_l, sigma_1, 0.9 * cuckoo_d_prob_l, 1.1 * cuckoo_d_prob_l)
            c_p_c = genNormalSampleValue(cuckoo_prob_c, sigma_1, 0, 2 * cuckoo_prob_c)
            c_p_s = genNormalSampleValue(cuckoo_prob_s, sigma_1, 0, 2 * cuckoo_prob_s)            
            c_e_n = round(genNormalSampleValue(cuckoo_egg_n, sigma_2, round(cuckoo_egg_n / 2), round(1.5 * cuckoo_egg_n)))
            
            c_p_c_set = {}
            c_p_s_set = {}
            for j in Reeds_set.keys():
                c_p_c_set[j] = c_p_c
                c_p_s_set[j] = c_p_s
            
            rand_num = numpy.random.uniform(0,1)
            if rand_num < 0.5:
                default_mom = random.sample(mom_set, 1)[0]
                temp_c.Female_Cuckoo.append(FemaleCuckoo(spe_name, c_p_h, life_C, age_C, \
                                                         c_p_l, c_d_p_l, c_p_c_set,\
                                                         c_p_s_set, c_e_n, False, default_mom))
            else:
                temp_c.Male_Cuckoo.append(MaleCuckoo(spe_name, c_p_h, life_C, age_C))
        temp_c.RemoveDeadCuckoo()
        temp_c.PassingCuckooGroupParams(sigma_1, sigma_2, cuckoo_life_low, cuckoo_life_high)
        Cuckoos[spe_name] = temp_c
        Life_c_l[spe_name] = cuckoo_life_low
        Life_c_r[spe_name] = cuckoo_life_high
    return CuckooGroups(Cuckoos), Life_c_l, Life_c_r

def CreateGradInitialCuckoos(Cuckoo_set, Reeds_set, order_1, order_2):
    Cuckoos = {}
    Life_c_l = {}
    Life_c_r = {}
    count = 0
    for key in Cuckoo_set.keys():     
        spe_name = Cuckoo_set.get(key).get('SPE_NAME')
        temp_c = CuckooGroup([],[], spe_name, cuckoo_choice)
        cuckoo_p_hatch = float(Cuckoo_set.get(key).get('PROB_ALIVE_EGG'))
        cuckoo_life_low = int(Cuckoo_set.get(key).get('LIFE_LOW'))
        cuckoo_life_high = int(Cuckoo_set.get(key).get('LIFE_HIGH'))
        cuckoo_life_m = float(Cuckoo_set.get(key).get('LIFE_M'))
        cuckoo_prob_lay = float(Cuckoo_set.get(key).get('PROB_LAY'))
        cuckoo_d_prob_l = float(Cuckoo_set.get(key).get('D_PROB_L'))
        cuckoo_prob_c = float(Cuckoo_set.get(key).get('PROB_C'))
        cuckoo_prob_s = float(Cuckoo_set.get(key).get('PROB_S'))
        cuckoo_egg_n = int(Cuckoo_set.get(key).get('EGG_N'))
        cuckoo_mom_n = int(Cuckoo_set.get(key).get('MOM_N'))
        cuckoo_pop_n = int(Cuckoo_set.get(key).get('POP_N'))
        mom_set = random.sample(Reeds_set.keys(), cuckoo_mom_n)
        if count == 0:
            count = count + 1
            cuckoo_prob_c = order_1
            cuckoo_prob_s = order_2
        for i in range(cuckoo_pop_n):
            life_C = round(genWeibullSampleValue(cuckoo_life_m, sigma_2, cuckoo_life_low, cuckoo_life_high))
            age_C = math.floor(numpy.random.uniform(0, life_C))
            
            c_p_h = genNormalSampleValue(cuckoo_p_hatch, sigma_1, 0, 1)
            c_p_l = genNormalSampleValue(cuckoo_prob_lay, sigma_1, 0, 1)
            c_d_p_l = genNormalSampleValue(cuckoo_d_prob_l, sigma_1, 0.9 * cuckoo_d_prob_l, 1.1 * cuckoo_d_prob_l)
            c_p_c = genNormalSampleValue(cuckoo_prob_c, sigma_1, 0, 2 * cuckoo_prob_c)
            c_p_s = genNormalSampleValue(cuckoo_prob_s, sigma_1, 0, 2 * cuckoo_prob_s)            
            c_e_n = round(genNormalSampleValue(cuckoo_egg_n, sigma_2, round(cuckoo_egg_n / 2), round(1.5 * cuckoo_egg_n)))
            
            c_p_c_set = {}
            c_p_s_set = {}
            for j in Reeds_set.keys():
                c_p_c_set[j] = c_p_c
                c_p_s_set[j] = c_p_s
            
            rand_num = numpy.random.uniform(0,1)
            if rand_num < 0.5:
                default_mom = random.sample(mom_set, 1)[0]
                temp_c.Female_Cuckoo.append(FemaleCuckoo(spe_name, c_p_h, life_C, age_C, \
                                                         c_p_l, c_d_p_l, c_p_c_set,\
                                                         c_p_s_set, c_e_n, False, default_mom))
            else:
                temp_c.Male_Cuckoo.append(MaleCuckoo(spe_name, c_p_h, life_C, age_C))
        temp_c.RemoveDeadCuckoo()
        temp_c.PassingCuckooGroupParams(sigma_1, sigma_2, cuckoo_life_low, cuckoo_life_high)
        Cuckoos[spe_name] = temp_c
        Life_c_l[spe_name] = cuckoo_life_low
        Life_c_r[spe_name] = cuckoo_life_high
    return CuckooGroups(Cuckoos), Life_c_l, Life_c_r

def CreateInitialReedsBirds(Cuckoo_set, Reeds_set):
    ReedsBirds = {}
    Life_r_l = {}
    Life_r_r = {}
    cuckoo_sum = 0
    reeds_sum = 0
    cuckoo_eggs_sum = 0
    coef_cr_1 = 0
    coef_cr_2 = 0
    coef_cr_3 = 0
    coef_cr_4 = 0
    coef_cr_5 = 0
    coef_cr_6 = 0
    for cuc in Cuckoo_set.keys():
        cuckoo_sum += int(Cuckoo_set.get(cuc).get('POP_N'))
        cuckoo_eggs_sum += int(Cuckoo_set.get(cuc).get('EGG_N'))
        coef_cr_1 += float(Cuckoo_set.get(cuc).get('PROB_LAY'))
        coef_cr_2 += float(Cuckoo_set.get(cuc).get('PROB_C'))
        coef_cr_3 += float(Cuckoo_set.get(cuc).get('PROB_S'))
    
    for red in Reeds_set.keys():
        reeds_sum += int(Reeds_set.get(red).get('POP_N'))
        coef_cr_4 += float(Reeds_set.get(red).get('P_STAY'))
        coef_cr_5 += float(Reeds_set.get(red).get('P_COLOR'))
        coef_cr_6 += float(Reeds_set.get(red).get('P_SHAPE'))
    
    print(cuckoo_eggs_sum / len(Cuckoo_set))
    
    cr_ratio_1 = (cuckoo_eggs_sum / len(Cuckoo_set)) * cuckoo_sum / reeds_sum
    cr_ratio_2 = coef_cr_1 / len(Cuckoo_set) - coef_cr_4 / len(Reeds_set)
    cr_ratio_3 = (1 - (coef_cr_2 / len(Cuckoo_set) - coef_cr_5 / len(Reeds_set))) * \
                (1 - (coef_cr_3 / len(Cuckoo_set) - coef_cr_6 / len(Reeds_set)))
    
    for key in Reeds_set.keys():
        spe_name = Reeds_set.get(key).get('SPE_NAME')
        Sig_Female_ReedsBird = []
        Sig_Male_ReedsBird = []
        reeds_p_coef1 = float(Reeds_set.get(key).get('P_COEF1'))
        reeds_p_coef2 = float(Reeds_set.get(key).get('P_COEF2'))
        reeds_p_coef3 = float(Reeds_set.get(key).get('P_COEF3'))
        reeds_p_coef4 = float(Reeds_set.get(key).get('P_COEF4'))
        reeds_life_low = int(Reeds_set.get(key).get('LIFE_LOW'))
        reeds_life_high = int(Reeds_set.get(key).get('LIFE_HIGH'))
        reeds_life_m = float(Reeds_set.get(key).get('LIFE_M'))
        reeds_p_hatch = float(Reeds_set.get(key).get('P_HATCH'))
        reeds_p_breed = float(Reeds_set.get(key).get('P_BREED'))
        reeds_p_shape = float(Reeds_set.get(key).get('P_SHAPE'))
        reeds_p_color = float(Reeds_set.get(key).get('P_COLOR'))
        reeds_p_stay = float(Reeds_set.get(key).get('P_STAY'))
        reeds_d_p_breed = float(Reeds_set.get(key).get('D_P_BREED'))
        reeds_d_p_shape = float(Reeds_set.get(key).get('D_P_SHAPE'))
        reeds_d_p_color = float(Reeds_set.get(key).get('D_P_COLOR'))
        reeds_d_p_stay = float(Reeds_set.get(key).get('D_P_STAY'))
        reeds_egg_n = int(Reeds_set.get(key).get('EGG_N'))
        reeds_pop_n = int(Reeds_set.get(key).get('POP_N'))
        reeds_orig_n = int(Reeds_set.get(key).get('ORIG_N'))
        Life_r_l[spe_name] = reeds_life_low
        Life_r_r[spe_name] = reeds_life_high
        for i in range(reeds_pop_n):
            life_R = round(genWeibullSampleValue(reeds_life_m, sigma_4, reeds_life_low, reeds_life_high))
            age_R = math.floor(numpy.random.uniform(0, life_R))
            N_st_up = math.ceil(age_R * cr_ratio_1 * cr_ratio_2)            
            N_st = random.uniform(0, min(life_R, 2 * N_st_up))
            N_cs_up = math.ceil(age_R * cr_ratio_1 * cr_ratio_3)            
            N_cs = random.uniform(0, min(life_R, 2 * N_cs_up))
            
            r_p_co1 = genNormalSampleValue(reeds_p_coef1, sigma_3, reeds_p_coef1 / 2, min(reeds_p_coef1 * 2, 2))
            r_p_co2 = genNormalSampleValue(reeds_p_coef2, sigma_3, reeds_p_coef2 / 2, min(reeds_p_coef2 * 2, 2))
            r_p_co3 = genNormalSampleValue(reeds_p_coef3, sigma_3, reeds_p_coef3 / 2, min(reeds_p_coef3 * 2, 2))
            r_p_co4 = genNormalSampleValue(reeds_p_coef4, sigma_3, reeds_p_coef4 / 2, min(reeds_p_coef4 * 2, 2))
            r_p_h = genNormalSampleValue(reeds_p_hatch, sigma_3, 0, 1)
            r_p_b = genNormalSampleValue(reeds_p_breed, sigma_3, 0, 1)
            r_p_c = genNormalSampleValue(reeds_p_color, sigma_3, 0, min(1, 2 * reeds_p_color))
            r_p_s = genNormalSampleValue(reeds_p_shape, sigma_3, 0, min(1, 2 * reeds_p_shape))
            r_p_st = genNormalSampleValue(reeds_p_stay, sigma_3, 0, min(1, 2 * reeds_p_stay))
            d_r_p_c = genNormalSampleValue(reeds_d_p_color, sigma_3, 0.9 * reeds_d_p_color, 1.1 * reeds_d_p_color)
            d_r_p_s = genNormalSampleValue(reeds_d_p_shape, sigma_3, 0.9 * reeds_d_p_shape, 1.1 * reeds_d_p_shape)
            d_r_p_b = genNormalSampleValue(reeds_d_p_breed, sigma_3, 0.9 * reeds_d_p_breed, 1.1 * reeds_d_p_breed)
            d_r_p_st = genNormalSampleValue(reeds_d_p_stay, sigma_3, 0.9 * reeds_d_p_stay, 1.1 * reeds_d_p_stay)
            r_p_c_0 = r_p_c + N_cs * d_r_p_c
            r_p_s_0 = r_p_s + N_cs * d_r_p_s
            r_p_b_0 = r_p_s + max(0, age_R - 1) * d_r_p_b
            r_p_st_0 = r_p_st + N_st * d_r_p_st            
            r_e_n = round(genNormalSampleValue(reeds_egg_n, sigma_4, round(reeds_egg_n / 2), round(1.5 * reeds_egg_n)))
            
            rand_num = numpy.random.uniform(0,1)
            if rand_num < 0.5:                            
                Sig_Female_ReedsBird.append(FemaleReedsBird(spe_name, r_p_co1, r_p_co2, r_p_co3, r_p_co4, r_p_h, r_p_b_0, r_p_b,\
                                                                   r_p_c_0, r_p_c, r_p_s_0, r_p_s, r_p_st_0, r_p_st, life_R, age_R,\
                                                                   d_r_p_c, d_r_p_s, d_r_p_b, d_r_p_st, r_e_n))
            else:
                Sig_Male_ReedsBird.append(MaleReedsBird(spe_name, r_p_co1, r_p_co2, r_p_co3, r_p_co4, r_p_h, r_p_b_0, r_p_b,\
                                                                   r_p_c_0, r_p_c, r_p_s_0, r_p_s, r_p_st_0, r_p_st, life_R, age_R,\
                                                                   d_r_p_c, d_r_p_s, d_r_p_b, d_r_p_st))
        ReedsBirds[spe_name] = ReedsBirdGroup(Sig_Male_ReedsBird, Sig_Female_ReedsBird, spe_name, reeds_orig_n, Pel)
        ReedsBirds[spe_name].RemoveDeadReedsBird()
        ReedsBirds[spe_name].PassingReedsBirdGroupParams(sigma_3, sigma_4, reeds_life_low, reeds_life_high)
    return ReedsBirdGroups(ReedsBirds), Life_r_l, Life_r_r

def YearlyGaming(cuckoos, reedsBirds, life_c_l, life_c_r, life_r_l, life_r_r, f):
    Baby_Male_Cuc = []
    Baby_Female_Cuc = []
    
    for c in cuckoos.getCuckoos().keys():
        # print([c,cuckoos.getCuckoos().get(c).getTotalCuckooNum()])
        f.write(str(cuckoos.getCuckoos().get(c).getTotalCuckooNum()))
        f.write(' ,')
        cuckoos.Cuckoos[c].CuckooFirstGaming() 
    for r in reedsBirds.getReedsBirds().keys():
        # print([r,reedsBirds.getReedsBirds().get(r).getTotalReedsBirdNum()])
        f.write(str(reedsBirds.getReedsBirds().get(r).getTotalReedsBirdNum()))
        f.write(' ,')
        reedsBirds.ReedsBirds[r].ReedsBirdFirstGaming()
    for c in cuckoos.getCuckoos().keys():
        temp_c = cuckoos.getCuckoos().get(c)
        cuckoos.Cuckoos[c].CuckooSecondGaming(reedsBirds)
        reedsBirds = cuckoos.Cuckoos[c].getUpdatedReedsBird()
        
    for r in reedsBirds.getReedsBirds().keys():
        reedsBirds.ReedsBirds[r].PassingReedsBirdGroupParams(sigma_3, sigma_4, life_r_l[r], life_r_r[r])
        babymalecuckoo = []
        babyfemalecuckoo = []
        reedsBirds.ReedsBirds[r].ReedsBirdSecondGaming()
        babymalecuckoo, babyfemalecuckoo = reedsBirds.ReedsBirds[r].getBabyCuckooHatchedbyReedsBird()
        # print([len(babymalecuckoo), len(babyfemalecuckoo)])
        Baby_Male_Cuc.append(babymalecuckoo)
        Baby_Female_Cuc.append(babyfemalecuckoo)
    for c in cuckoos.getCuckoos().keys():
        cuckoos.Cuckoos[c].PassingCuckooGroupParams(sigma_1, sigma_2, life_c_l[c], life_c_r[c])
        cuckoos.Cuckoos[c].CuckooFinalGaming(Baby_Male_Cuc, Baby_Female_Cuc)
    for r in reedsBirds.getReedsBirds().keys():
        reedsBirds.ReedsBirds[r].ReedsBirdFinalGaming()
    return cuckoos, reedsBirds

if __name__ == "__main__":
    if simu_type == 'a' or simu_type == 'A':
        
        Cuckoo_data = ReadCuckooInitialFile(cuckoo_dir)
        Reeds_data = ReadReedsInitialFile(reeds_dir)
        
        for i in range(M):
            Cuckoos, Life_c_l, Life_c_r = CreateInitialCuckoos(Cuckoo_data, Reeds_data)
            Reeds, Life_r_l, Life_r_r = CreateInitialReedsBirds(Cuckoo_data, Reeds_data)
        
            name = 'result_' + simu_type + '_' + str(i) + '.txt'
            path = f'{out_dir}/{name}'
            f = open(path,'w')
            f.write('YEAR ,')
            for c in Cuckoos.getCuckoos().keys():
                f.write(c + ' ,')
            for r in Reeds.getReedsBirds().keys():
                f.write(r + ' ,')
            f.write('\n')
            for j in range(Y):
                f.write(str(j) + ' ,')
                # print('================= The %d iteration =================='% j)
                Cuckoos, Reeds = YearlyGaming(Cuckoos, Reeds, Life_c_l, Life_c_r, Life_r_l, Life_r_r, f)
                f.write('\n')
            f.close()
            
    elif simu_type == 'b' or simu_type == 'B':
        Cuckoo_data = ReadCuckooInitialFile(cuckoo_dir)
        Reeds_data = ReadReedsInitialFile(reeds_dir)
        num_c, low_c, high_c, num_s, low_s, high_s = getInitialCuckooVals(Cuckoo_data)
        l_c = 0 if not args.c_list else args.c_list[0]
        r_c = num_c + 1 if not args.c_list else args.c_list[1]
        l_s = 0 if not args.s_list else args.s_list[0]
        r_s = num_s + 1 if not args.s_list else args.s_list[1]
        for x in range(l_c, r_c):
            for y in range(l_s, r_s):
                order_1 = low_c + x * delta_test
                order_2 = low_s + y * delta_test
                # print("order_1 is %f, order_2 is %f in current iteration" %(order_1, order_2))
                CheckIfFolderExist('/' + str(x) + '_' +  str(y) + '/')
                save_dir = str(x) + '_' +  str(y)
                for i in range(M):
                    Cuckoos, Life_c_l, Life_c_r = CreateGradInitialCuckoos(Cuckoo_data, Reeds_data, order_1, order_2)
                    Reeds, Life_r_l, Life_r_r = CreateInitialReedsBirds(Cuckoo_data, Reeds_data)
                
                    name = 'result_' + simu_type + '_' + str(i) + '.txt'
                    path = f'{out_dir}/{save_dir}/{name}'
                    f = open(path,'w')
                    f.write('YEAR ,')
                    for c in Cuckoos.getCuckoos().keys():
                        f.write(c + ' ,')
                    for r in Reeds.getReedsBirds().keys():
                        f.write(r + ' ,')
                    f.write('\n')
                    for j in range(Y):
                        f.write(str(j) + ' ,')
                        # print('================= The %d iteration =================='% j)
                        Cuckoos, Reeds = YearlyGaming(Cuckoos, Reeds, Life_c_l, Life_c_r, Life_r_l, Life_r_r, f)
                        f.write('\n')
                    f.close()
   
