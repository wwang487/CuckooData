# -*- coding: utf-8 -*-
"""
Created on Thu Jul 16 16:56:38 2020

@author: bbean
"""

from Cuckoo import *
from CuckooEgg import *

class CuckooGroups:
    Cuckoos = {}
    def __init__(self, Cuckoos):
        self.Cuckoos = Cuckoos
        
    def modifyCuckoosSpe(self, spe, cuckoo):
        self.Cuckoos[spe] = cuckoo
    
    def delCuckoosSpe(self, spe):
        if spe in self.Cuckoos:
            self.Cuckoos.pop(spe)
            
    def getCuckoos(self):
        return self.Cuckoos
    
    def setRCuckoos(self, cuc_dict):
        self.Cuckoos = cuc_dict
        
    def getCuckoosSpeNum(self):
        count = 0
        for k in self.Cuckoos:
            count = count + 1
        return count
    
    def DelExtinctCuckoos(self):
        for k in self.Cuckoos:
            if self.Cuckoos.get(k).getTotalReedsBirdNum() == 0:
                self.Cuckoos.pop(k)
                
    def getAvgCuckooPopSize(self):
        cuckoo_sum = 0
        for key in self.Cuckoos.keys():
            cuckoo_sum += self.Cuckoos.get(key).getTotalCuckooNum()
        return cuckoo_sum / len(self.Cuckoos)
    
    def getAvgCuckooEggNum(self):
        egg_sum = 0
        for key in self.Cuckoos.keys():
            egg_sum += self.Cuckoos.get(key).getTotalCuckooNum() * self.Cuckoos.get(key).getTotalCuckooEggNum()
        return egg_sum / len(self.Cuckoos)