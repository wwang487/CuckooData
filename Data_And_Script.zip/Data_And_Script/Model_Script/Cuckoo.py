from ParasiteRand import *
from CuckooEgg import *
from ReedsBird import *
class Cuckoo:
    # prob: probability ~ alive egg
    # life: lifetime
    # age: age
    def __init__(self, spe_name, prob, life, age):
        self.prob = prob
        self.life = life
        self.age = age
        self.spe_name = spe_name
    
    def setCuckooAge(self, n):
        self.age = n
        
    def setCuckooLife(self, m):
        self.life = m
    
    def setCuckooHatchProb(self, p1):
        self.prob = p1
    
    def setCuckooSpeName(self, name):
        self.spe_name = name
    
    def getCuckooSpeName(self):
        return self.spe_name
    
    def getCuckcooAge(self):
        return self.age
    
    def getCuckooLife(self):
        return self.life
    
    def getCuckooRemYrs(self):
        return self.life - self.age
    
    def getCuckooHatchProb(self):
        return self.prob
    
    def isCuckooDead(self):
        if self.getCuckooRemYrs() > 0:
            return False
        else:
            return True
    
    def growCuckoo(self):
        self.age = self.age + 1
        
    def printCuckoo(self):
        print('==============================   It is a male cuckoo   =====================================\n')
        print('Age of this cuckoo is: %d, Lifetime of this cuckoo is: %d.\n'%(self.age,self.life))

class FemaleCuckoo(Cuckoo):
    # prob_1 : prob of successfully laying eggs
    # dp1: reinforcement factor for laying
    # N: number of eggs
    # is_Preg: if it is Preg
    # PCR_c: probability to cheat for cheating ReedsBird, IT IS A DICT (color)
    # PCR_s: probability to cheat for cheating ReedsBird, IT IS A DICT (shape)
    # def_mom: default brood species
    Egg_list = []
    
    def __init__(self, spe_name, prob, life, age, prob_1, dp1, PCR_c, PCR_s, N, is_Preg, def_mom):
        super(FemaleCuckoo,self).__init__(spe_name, prob, life, age)
        self.prob_1 = prob_1
        self.PROB_1 = prob_1
        self.PCR_c = PCR_c
        self.PCR_s = PCR_s
        self.dp1 = dp1
        self.N = N
        self.is_Preg = is_Preg
        self.def_mom = def_mom
    
    def getCuckooEggNum(self):
        return self.N
    
    def setCuckooEggNum(self, N0):
        self.N = N0
        
    def getCuckooBaseLaidProb(self):
        return self.prob_1
    
    def setCuckooBaseLaidProb(self, p1):
        self.prob_1 = p1
        
    def getCuckooActLaidProb(self):
        return self.PROB_1
    
    def setCuckooActLaidProb(self, p1):
        self.PROB_1 = p1    
    
    def getCuckooLaidReinFac(self):
        return self.dp1
    
    def setCuckooLaidReinFac(self, dp):
        self.dp1 = dp
    
    def getPregCond(self):
        return self.is_Preg
    
    def setPregCond(self, Preg_Cond):
        self.is_Preg = Preg_Cond
    
    def getTotalCuckooColorReinFac(self):
        return self.PCR_c
    
    def getSigCuckooColorReinFac(self, key):
        return self.PCR_c.get(key)
    
    def getTotalCuckooShapeReinFac(self):
        return self.PCR_s
    
    def getSigCuckooShapeReinFac(self, key):
        return self.PCR_s.get(key)
    
    def getdefaultmom(self):
        return self.def_mom
    
    def setdefaultmom(self, spe):
        self.def_mom = spe
    
    def setSigCuckooReinFac(self, key, val):
        self.PCR[key] = val
    
    def setTotalCuckooReinFac(self, P):
        self.PCR = P
        
    def getFemaleCuckooEggs(self):
        return self.Egg_list
    
    
    
    def setFemaleCuckooEggs(self, eggs):
        self.Egg_list = eggs
    
    def apprendOneEgg(self, egg):
        self.Egg_list.append(egg)
        
    def UpdateFemaleCuckooLaid(self):
        self.PROB_1 = min(self.PROB_1 + self.dp1, 1)
        
    def printCuckoo(self):
        print('=============================   It is a female cuckoo   ====================================\n')
        print('Age of this cuckoo is: %d, Lifetime of this cuckoo is: %d. \n'%(self.age,self.life))
        print('The maximum number of laying eggs is: %f, current probability for cheating is: %f.\n'%(self.N,self.prob_1))
        if self.getPregCond():
            print('In this turn, it is Pregnant!\n')
        else:
            print('In this turn, it is Not Pregnant!\n')
    
class MaleCuckoo(Cuckoo):
    pass

