from ReedsBird import *
from ReedsBirdPair import *
from Cuckoo import *
from CuckooEgg import *
import random
import numpy
from ParasiteRand import *

class ReedsBirdGroup:
    
    
    def __init__(self, Sig_Male_ReedsBird, Sig_Female_ReedsBird, spe_mark, orig_N, penalty_val):
        self.Sig_Male_ReedsBird = Sig_Male_ReedsBird
        self.Sig_Female_ReedsBird = Sig_Female_ReedsBird
        self.spe_mark = spe_mark
        self.Non_occupied_pairs = []
        self.Occupied_pairs = []

        self.baby_male_Cuckoo = []
        self.baby_female_Cuckoo = []
        self.count_1 = 0
        self.count_2 = 0
        self.penalty_value = penalty_val
        self.Orig_N = orig_N
        self.s0 = 1
    
        self.sigma_1 = 0.1
        self.sigma_2 = 1
        self.l_low = 0
        self.l_high = 4
    
    def PassingReedsBirdGroupParams(self, val_1, val_2, val_3, val_4):
        self.sigma_1 = val_1
        self.sigma_2 = val_2
        self.l_low = val_3
        self.l_high = val_4
    # Set if the natural Condition is good or not.
    def PassingReedsBirdNaturalVar(self, s0):
        self.s0 = s0
    
    def setReedsBirdSpeName(self, name):
        self.spe_mark = name
        
    def getReedsBirdSpeName(self):
        return self.spe_mark
    
    def setOrigReedsBirdNum(self, N0):
        self.Orig_N = N0
    
    def setReedsBirdPenaltyValue(self, M):
        self.penalty_value = M
    
    def getOccupiedReedsBirdPairs(self):
        return self.Occupied_pairs
    
    def getNonOccupiedReedsBirdPairs(self):
        return self.Non_Occupied_pairs
    
    def getSigOccupiedReedsBirdPair(self, ind):
        return self.Occupied_pairs[ind]
    
    def getSigNonOccupiedReedsBirdPair(self, ind):
        return self.Non_occupied_pairs[ind]
    
    def getSigMaleReedsBirdNum(self):
        if not self.Sig_Male_ReedsBird:
            return 0
        else:
            return len(self.Sig_Male_ReedsBird)
    
    def getSigFemaleReedsBirdNum(self):
        if not self.Sig_Female_ReedsBird:
            return 0
        else:
            return len(self.Sig_Female_ReedsBird)
    
    def getReedsBirdGroupDetectProb(self):
        return self.PROB_1
    
    def setReedsBirdGroupDetectProb(self, P):
        self.PROB_1 = P
    
    def getReedsBirdPairNum(self):
        return self.getNonOccupiedReedsBirdPairNum() + self.getOccupiedReedsBirdPairNum()
    
    def getTotalMaleReedsBirdNum(self):
        return self.getSigMaleReedsBirdNum() + self.getNonOccupiedReedsBirdPairNum() + self.getOccupiedReedsBirdPairNum()
    
    def getTotalFemaleReedsBirdNum(self):
        return self.getSigFemaleReedsBirdNum() + self.getNonOccupiedReedsBirdPairNum() + self.getOccupiedReedsBirdPairNum()
    
    def getTotalReedsBirdNum(self):
        return self.getTotalMaleReedsBirdNum() + self.getTotalFemaleReedsBirdNum()
    
    def getSigFemaleReedsBird(self):
        return self.Sig_Female_ReedsBird
    
    def getSigMaleReedsBird(self):
        return self.Sig_male_ReedsBird
    
    def getReedsBirdPairs(self):
        return self.ReedsBirdPairs
    
    def AddSigMaleReedsBird(self, male):
        self.Sig_Male_ReedsBird.append(male)
    
    def AddSigFemaleReedsBird(self, female):
        self.Sig_Female_ReedsBird.append(female)
        
    def AddReedsBirdPair(self, pair):
        self.ReedsBirdPairs.append(pair)
    
    def addOneAge2ReedsBird(self):
        Sig_Male_Num = self.getSigMaleReedsBirdNum()
        Sig_Female_Num = self.getSigFemaleReedsBirdNum()
        Occupied_Num = self.getOccupiedReedsBirdPairNum()
        Non_Occupied_Num = self.getNonOccupiedReedsBirdPairNum()
        for i in range(Sig_Female_Num):
            self.Sig_Female_ReedsBird[i].growReedsBird()
        for i in range(Sig_Male_Num):
            self.Sig_Male_ReedsBird[i].growReedsBird()
        for i in range(Occupied_Num):
            self.Occupied_pairs[i].growReedsBirdinPair()
        for i in range(Non_Occupied_Num):
            self.Non_occupied_pairs[i].growReedsBirdinPair()
    
    def ResetCount(self):
        self.count_1 = 0
        self.count_2 = 0
    
    def clearReedsInitParams(self):
        self.Sig_Male_ReedsBird = []
        self.Sig_Female_ReedsBird = []
        self.Non_occupied_pairs = []
        self.Occupied_pairs = []
    
    def RemoveDeadReedsBird(self):
        Sig_Male_Num = self.getSigMaleReedsBirdNum()
        Sig_Female_Num = self.getSigFemaleReedsBirdNum()
        Occupied_Num = self.getOccupiedReedsBirdPairNum()
        Non_Occupied_Num = self.getNonOccupiedReedsBirdPairNum()
        o0 = Occupied_Num - 1
        n0 = Non_Occupied_Num - 1
        m0 = Sig_Male_Num - 1
        f0 = Sig_Female_Num - 1
        while o0 >= 0:
            if self.Occupied_pairs[o0].getFemaleReedsBirdinPair().isReedsBirdDead() \
            and self.Occupied_pairs[o0].getMaleReedsBirdinPair().isReedsBirdDead():
                self.Occupied_pairs.pop(o0)
            elif self.Occupied_pairs[o0].getFemaleReedsBirdinPair().isReedsBirdDead():
                self.Sig_Male_ReedsBird.append(self.Occupied_pairs[o0].getMaleReedsBirdinPair())
                self.Occupied_pairs.pop(o0)
            elif self.Occupied_pairs[o0].getMaleReedsBirdinPair().isReedsBirdDead():
                self.Sig_Female_ReedsBird.append(self.Occupied_pairs[o0].getFemaleReedsBirdinPair())
                self.Occupied_pairs.pop(o0)
            o0 = o0 - 1
        
        while n0 >= 0:
            if self.Non_occupied_pairs[n0].getFemaleReedsBirdinPair().isReedsBirdDead() \
            and self.Non_occupied_pairs[n0].getMaleReedsBirdinPair().isReedsBirdDead():
                self.Non_occupied_pairs.pop(n0)
            elif self.Non_occupied_pairs[n0].getFemaleReedsBirdinPair().isReedsBirdDead():
                self.Sig_Male_ReedsBird.append(self.Non_occupied_pairs[n0].getMaleReedsBirdinPair())
                self.Non_occupied_pairs.pop(n0)
            elif self.Non_occupied_pairs[n0].getMaleReedsBirdinPair().isReedsBirdDead():
                self.Sig_Female_ReedsBird.append(self.Non_occupied_pairs[n0].getFemaleReedsBirdinPair())
                self.Non_occupied_pairs.pop(n0)
            n0 = n0 - 1
        
        while f0 >= 0:
            if self.Sig_Female_ReedsBird[f0].isReedsBirdDead():
                self.Sig_Female_ReedsBird.pop(f0)
            f0 = f0 - 1    
        while m0 >= 0:
            if self.Sig_Male_ReedsBird[m0].isReedsBirdDead():
                self.Sig_Male_ReedsBird.pop(m0)
            m0 = m0 - 1
    
    def BuildNewReedsBirdPair(self):
        to_Pair_Num = min(self.getSigFemaleReedsBirdNum(), self.getSigMaleReedsBirdNum())
        random.shuffle(self.Sig_Male_ReedsBird)
        random.shuffle(self.Sig_Female_ReedsBird)
        for i in range(to_Pair_Num):
            temp_NonOccupiedPair = NonOccupiedReedsBirdPair(self.Sig_Male_ReedsBird.pop(0), self.Sig_Female_ReedsBird.pop(0), False)
            temp_NonOccupiedPair.calReedsBirdPairCDectProb()
            temp_NonOccupiedPair.calReedsBirdPairSDectProb()
            temp_NonOccupiedPair.passReedsBirdGroupCoef(self.l_low, self.l_high, self.sigma_1, self.sigma_2)
            self.Non_occupied_pairs.append(temp_NonOccupiedPair)
    
    def clearOccupiedReedsBirdPair(self):
        while self.Occupied_pairs:
            male_reedsbird = self.Occupied_pairs[0].getMaleReedsBirdinPair()
            female_reedsbird = self.Occupied_pairs[0].getFemaleReedsBirdinPair()
            temp_NonOccupiedPair = NonOccupiedReedsBirdPair(male_reedsbird, female_reedsbird, False)
            temp_NonOccupiedPair.calReedsBirdPairCDectProb()
            temp_NonOccupiedPair.calReedsBirdPairSDectProb()
            self.Occupied_pairs.pop(0)
            self.Non_occupied_pairs.append(temp_NonOccupiedPair)
            
    def getNonOccupiedReedsBirdPairNum(self):
        if not self.Non_occupied_pairs:
            return 0
        else:
            return len(self.Non_occupied_pairs)
    
    def getOccupiedReedsBirdPairNum(self):
        if not self.Occupied_pairs:
            return 0
        else:
            return len(self.Occupied_pairs)
        
    def updateNonOccupiedReedsBirdPairs(self, ind, cuckooEgg):
        male_reedsbird = self.Non_occupied_pairs[ind].getMaleReedsBirdinPair()
        female_reedsbird = self.Non_occupied_pairs[ind].getFemaleReedsBirdinPair()
        temp_OccupiedPair = OccupiedReedsBirdPair(male_reedsbird, female_reedsbird, False, cuckooEgg)
        temp_OccupiedPair.calReedsBirdPairCDectProb()
        temp_OccupiedPair.calReedsBirdPairSDectProb()
        temp_OccupiedPair.passReedsBirdGroupCoef(self.l_low, self.l_high, self.sigma_1, self.sigma_2)
        self.Non_occupied_pairs.pop(ind)
        self.Occupied_pairs.append(temp_OccupiedPair)

    def ReedsBirdAfterBadEnvSce(self):
        pass
        

    def getBabyMaleReedsBirdPopulation(self):
        count = 0
        Male_Num = self.getSigMaleReedsBirdNum()
        Non_Occupied_Num = self.getNonOccupiedReedsBirdPairNum()
        Occupied_Num = self.getOccupiedReedsBirdPairNum()
        for i in range(Male_Num):
            if self.Sig_Male_ReedsBird[i].getReedsBirdAge() == 0:
                count = count + 1
        for i in range(Non_Occupied_Num):
            if self.Non_occupied_pairs[i].male_reedsbird.getReedsBirdAge() == 0:
                count = count + 1
        for i in range(Occupied_Num):
            if self.Occupied_pairs[i].male_reedsbird.getReedsBirdAge() == 0:
                count = count + 1
        return count
    
    def getBabyFemaleReedsBirdPopulation(self):
        count = 0
        Female_Num = self.getSigFemaleReedsBirdNum()
        Non_Occupied_Num = self.getNonOccupiedReedsBirdPairNum()
        Occupied_Num = self.getOccupiedReedsBirdPairNum()
        for i in range(Female_Num):
            if self.Sig_Female_ReedsBird[i].getReedsBirdAge() == 0:
                count = count + 1
        for i in range(Non_Occupied_Num):
            if self.Non_occupied_pairs[i].female_reedsbird.getReedsBirdAge() == 0:
                count = count + 1
        for i in range(Occupied_Num):
            if self.Occupied_pairs[i].female_reedsbird.getReedsBirdAge() == 0:
                count = count + 1
        return count
    
    def getBabyCuckooHatchedbyReedsBird(self):
        return self.baby_male_Cuckoo,self.baby_female_Cuckoo
    
    def ResetBabyCuckooHatchedbyReedsBird(self):
        self.baby_female_Cuckoo = []
        self.baby_male_Cuckoo = []
        
    def CalReedsBirdAvgRealBreedCap(self):    
        pass
        
    def updateCrowdedBreedingProb(self):
        TotalNum = self.getTotalReedsBirdNum()
        ratio = TotalNum / self.Orig_N
        penVal = math.exp(2 * self.penalty_value * (ratio + 0.0001))
        # print([TotalNum, self.Orig_N, penVal])
        NonReedsBirdPairNum = self.getNonOccupiedReedsBirdPairNum()
        for i in range(NonReedsBirdPairNum):
            self.Non_occupied_pairs[i].updateCrowdBreedPenalty(penVal)
        OccReedsBirdPairNum = self.getOccupiedReedsBirdPairNum()
        for i in range(OccReedsBirdPairNum):
            self.Occupied_pairs[i].updateCrowdBreedPenalty(penVal)
            
    def getReedsBirdGroupBaseSDectProb(self):
        Sig_Male_Num = self.getSigMaleReedsBirdNum()
        Sig_Female_Num = self.getSigFemaleReedsBirdNum()
        Occupied_Num = self.getOccupiedReedsBirdPairNum()
        Non_Occupied_Num = self.getNonOccupiedReedsBirdPairNum()
        pcount = 0
        for i in range(Sig_Female_Num):
            pcount += self.Sig_Female_ReedsBird[i].getBaseReedsBirdSDectProb()
        for i in range(Sig_Male_Num):
            pcount += self.Sig_Male_ReedsBird[i].getBaseReedsBirdSDectProb()
        for i in range(Occupied_Num):
            pcount += self.Occupied_pairs[i].getMaleReedsBirdinPair().getBaseReedsBirdSDectProb()
            pcount += self.Occupied_pairs[i].getFemaleReedsBirdinPair().getBaseReedsBirdSDectProb()
        for i in range(Non_Occupied_Num):
            pcount += self.Non_occupied_pairs[i].getMaleReedsBirdinPair().getBaseReedsBirdSDectProb()
            pcount += self.Non_occupied_pairs[i].getFemaleReedsBirdinPair().getBaseReedsBirdSDectProb()
        return pcount / self.getTotalReedsBirdNum()
    
    def getReedsBirdGroupBaseCDectProb(self):
        Sig_Male_Num = self.getSigMaleReedsBirdNum()
        Sig_Female_Num = self.getSigFemaleReedsBirdNum()
        Occupied_Num = self.getOccupiedReedsBirdPairNum()
        Non_Occupied_Num = self.getNonOccupiedReedsBirdPairNum()
        pcount = 0
        for i in range(Sig_Female_Num):
            pcount += self.Sig_Female_ReedsBird[i].getBaseReedsBirdCDectProb()
        for i in range(Sig_Male_Num):
            pcount += self.Sig_Male_ReedsBird[i].getBaseReedsBirdCDectProb()
        for i in range(Occupied_Num):
            pcount += self.Occupied_pairs[i].getMaleReedsBirdinPair().getBaseReedsBirdCDectProb()
            pcount += self.Occupied_pairs[i].getFemaleReedsBirdinPair().getBaseReedsBirdCDectProb()
        for i in range(Non_Occupied_Num):
            pcount += self.Non_occupied_pairs[i].getMaleReedsBirdinPair().getBaseReedsBirdCDectProb()
            pcount += self.Non_occupied_pairs[i].getFemaleReedsBirdinPair().getBaseReedsBirdCDectProb()
        return pcount / self.getTotalReedsBirdNum()
    
    def ReedsBirdFirstGaming(self):
        self.BuildNewReedsBirdPair()
        self.ResetCount()
        OccReedsBirdPairNum = self.getOccupiedReedsBirdPairNum()
        NonReedsBirdPairNum = self.getNonOccupiedReedsBirdPairNum()
        self.count_2 = OccReedsBirdPairNum + NonReedsBirdPairNum
    #    SigFemaleReedsBirdNum = reedsbirdgroup.getSigFemaleReedsBirdNum()
    #    SigMaleReedsBirdNum = reedsbirdgroup.getSigFemaleReedsBirdNum()
        for i in range(OccReedsBirdPairNum):
            self.Occupied_pairs[i].calReedsBirdPairCDectProb()
            self.Occupied_pairs[i].calReedsBirdPairSDectProb()
            self.Occupied_pairs[i].LearnReedsBirdDectProbFromPair()
        for i in range(NonReedsBirdPairNum):
            self.Non_occupied_pairs[i].calReedsBirdPairCDectProb()
            self.Non_occupied_pairs[i].calReedsBirdPairSDectProb()
            self.Non_occupied_pairs[i].LearnReedsBirdDectProbFromPair()
        self.addOneAge2ReedsBird()
        
    def ReedsBirdSecondGaming(self):
        self.ResetBabyCuckooHatchedbyReedsBird()
        self.updateCrowdedBreedingProb()
        OccReedsBirdPairNum = self.getOccupiedReedsBirdPairNum()
        NonReedsBirdPairNum = self.getNonOccupiedReedsBirdPairNum()
        # if not occupied
        for i in range(NonReedsBirdPairNum):
            Baby_male, Baby_female = self.Non_occupied_pairs[i].NonOccupiedOperation()
            Baby_male_num = len(Baby_male) if Baby_male else 0
            Baby_female_num = len(Baby_female) if Baby_female else 0
            for j in range(Baby_male_num):
                self.AddSigMaleReedsBird(Baby_male[j])
            for j in range(Baby_female_num):
                self.AddSigFemaleReedsBird(Baby_female[j])
            self.Non_occupied_pairs[i].ReedsBridPairBreedLearning()
        # if occupied
        for i in range(OccReedsBirdPairNum):
            CDect_prob = self.Occupied_pairs[i].getReedsBirdPairCDectProb() - self.Occupied_pairs[i].getOccupiedCuckooEgg().\
                getCuckooEggCCheatingReinFac().get(self.spe_mark)
            SDect_prob = self.Occupied_pairs[i].getReedsBirdPairSDectProb() - self.Occupied_pairs[i].getOccupiedCuckooEgg().\
                getCuckooEggSCheatingReinFac().get(self.spe_mark)
            Cuckoo_Hatch_prob = self.Occupied_pairs[i].getOccupiedCuckooEgg().getCuckooEggHatchingProb()
            Dect_prob = 1 - (1 - CDect_prob) * (1 - SDect_prob)
            if IsReallyDetected(Dect_prob):
                self.count_1 = self.count_1 + 1
                Baby_male, Baby_female = self.Occupied_pairs[i].OccupiedReeWinOperation()
                Baby_male_num = len(Baby_male) if Baby_male else 0
                Baby_female_num = len(Baby_female) if Baby_female else 0
                for j in range(Baby_male_num):
                    self.AddSigMaleReedsBird(Baby_male[j])
                for j in range(Baby_female_num):
                    self.AddSigFemaleReedsBird(Baby_female[j])
            else:
                if IsReallyHatched(Cuckoo_Hatch_prob):
                    Breed_Prob = self.Occupied_pairs[i].getReedsBirdPairRealBreedCap()
                    if IsReallyAlive(Breed_Prob):
                        self.Occupied_pairs[i].OccupiedCucWinOperation()
                        cuckooEgg = self.Occupied_pairs[i].getOccupiedCuckooEgg()
                        if IsFemaleBaby(0.5):
                            spe_name, prob, life_C, age, prob_1, dp1, PCR_c, PCR_s, N, is_Preg, mom = cuckooEgg.HatchFemaleEgg()
                            baby_female_cuckoo = FemaleCuckoo(spe_name, prob, life_C, age, prob_1, dp1, PCR_c, PCR_s, N, is_Preg, mom)
                            self.baby_female_Cuckoo.append(baby_female_cuckoo)
                        else:
                            spe_name, prob, life_C, age = cuckooEgg.HatchMaleEgg()
                            self.baby_male_Cuckoo.append(MaleCuckoo(spe_name, prob, life_C, age))
                else:
                    Baby_male, Baby_female = self.Occupied_pairs[i].OccupiedCucDeadEggOperation()
                    Baby_male_num = len(Baby_male) if Baby_male else 0
                    Baby_female_num = len(Baby_female) if Baby_female else 0
                    for j in range(Baby_male_num):
                        self.AddSigMaleReedsBird(Baby_male[j])
                    for j in range(Baby_female_num):
                        self.AddSigFemaleReedsBird(Baby_female[j])
            self.Occupied_pairs[i].ReedsBridPairBreedLearning()
        
             
    def ReedsBirdFinalGaming(self):
        self.RemoveDeadReedsBird()
        self.clearOccupiedReedsBirdPair()
        self.ResetBabyCuckooHatchedbyReedsBird()
        
        
    
    def countReedsBirdProp(self):
        Female_Num = self.getTotalFemaleReedsBirdNum()
        Male_Num = self.getTotalMaleReedsBirdNum()
        Total_Num = self.getTotalReedsBirdNum()
        New_Female_Num = self.getBabyFemaleReedsBirdPopulation()
        New_Male_Num = self.getBabyMaleReedsBirdPopulation()
        Dect_Rate = self.count_1 / self.count_2 if self.count_2 > 0 else 0
        Base_Dect_Rate = self.getReedsBirdGroupBaseDectProb()
        res = [Female_Num, Male_Num, Total_Num, New_Female_Num, New_Male_Num, Dect_Rate, Base_Dect_Rate]
        return res