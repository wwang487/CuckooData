from Cuckoo import *
from CuckooGroup import *
from CuckooGroups import *
from ReedsBird import *
from ReedsBirdPair import *
from ReedsBirdGroup import *
from ReedsBirdGroups import *
from ReadSpeData import *
from ParasiteRand import *
from Interaction import *
import numpy
import numpy as np
import random
import math
import matplotlib.pyplot as plt
import argparse
import os

parser = argparse.ArgumentParser(description = 'Environment Settings', formatter_class = argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('-c', '--cuckoopath', dest = 'cuckoopath', type = str, default = r"./VALIDATION/",
                        help='Path to where the cuckoo file is saved')
parser.add_argument('-r', '--reedspath', dest = 'reedspath', type = str, default = r"./VALIDATION/",
                        help='Path to where the reeds file is saved')
parser.add_argument('-o', '--outpath', dest = 'outpath', type = str, default = r"./VALIDATION/VALID_OUT/",
                        help='Path to where the OUTPUT file is saved')

parser.add_argument('-c1', '--cuckoofile', dest = 'cuckoofile', type = str, default = 'Cuckoo_v1.csv',
                        help='cuckoo file name')
parser.add_argument('-r1', '--reedsfile', dest = 'reedsfile', type = str, default = 'Reeds_v1.csv',
                        help='reeds file name')

parser.add_argument('-q', '--question', dest = 'question', type = str, default = 'a',
                        help='do question 1 or 2')

parser.add_argument('-d', '--delta', dest = 'delta', type = float, default = 0.05,
                        help='prob interval in simulation')

parser.add_argument('-ch', '--choice', dest = 'choice', type = bool, default = True, help = 'Is cuckoo re-select')
parser.add_argument('-s1', '--sigma1', dest = 'sigma1', type = float, default = 0.02, help = 'sigma for cuckoo_cont')
parser.add_argument('-s2', '--sigma2', dest = 'sigma2', type = float, default = 1, help = 'sigma for cuckoo_discrete')
parser.add_argument('-s3', '--sigma3', dest = 'sigma3', type = float, default = 0.02, help = 'sigma for reeds_cont')
parser.add_argument('-s4', '--sigma4', dest = 'sigma4', type = float, default = 1, help = 'sigma for reeds _discrete')

parser.add_argument('-Y1', '--startyear', dest = 'startyear', type = int, default = 1985, help = 'START YEAR')
parser.add_argument('-Y2', '--endyear', dest = 'endyear', type = int, default = 1997, help = 'END YEAR')
parser.add_argument('-M', '--iter', dest = 'iter', type = int, default = 100, help = 'number of simulations')
parser.add_argument('-P', '--penalty', dest = 'penalty', type =float, default = 0.9, help = 'penalty coef of crowding')

args = parser.parse_args()
cuckoo_choice = args.choice
sigma_1 = args.sigma1
sigma_2 = args.sigma2
sigma_3 = args.sigma3
sigma_4 = args.sigma4
Y = args.endyear - args.startyear + 1
Pel = args.penalty
M = args.iter
cuckoo_dir = args.cuckoopath + args.cuckoofile
reeds_dir = args.reedspath + args.reedsfile
simu_type = args.question
delta_test = args.delta
out_dir = args.outpath + args.cuckoofile.split('.')[0] +  '_' + args.reedsfile.split('.')[0] + '_' + simu_type

if args.choice:
    out_dir = out_dir + '_tr'
else:
    out_dir = out_dir + '_fl' 

def CheckIfFolderExist(suffix):
    if os.path.exists(f'{out_dir}{suffix}'):
        pass
    else:
        os.mkdir(f'{out_dir}{suffix}')

CheckIfFolderExist('')

if __name__ == "__main__": 
    Cuckoo_data = ReadCuckooInitialFile(cuckoo_dir)
    Reeds_data = ReadReedsInitialFile(reeds_dir)
    for i in range(M):
        Cuckoos, Life_c_l, Life_c_r = CreateInitialCuckoos(Cuckoo_data, Reeds_data)
        Reeds, Life_r_l, Life_r_r = CreateInitialReedsBirds(Cuckoo_data, Reeds_data)
        
        name = 'result_' + simu_type + '_' + str(i) + '.txt'
        path = f'{out_dir}/{name}'
        f = open(path,'w')
        f.write('YEAR ,')
        for c in Cuckoos.getCuckoos().keys():
            f.write(c + ',')
        for r in Reeds.getReedsBirds().keys():
            f.write(r + ',')
        f.write('\n')
        for j in range(Y):
            f.write(str(j) + ',')
            print('================= The %d iteration =================='% j)
            Cuckoos, Reeds = YearlyGaming(Cuckoos, Reeds, Life_c_l, Life_c_r, Life_r_l, Life_r_r, f)
            f.write('\n')
        f.close()