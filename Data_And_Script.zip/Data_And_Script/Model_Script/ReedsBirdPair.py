from ReedsBird import *
from CuckooEgg import *
from ParasiteRand import *
import math

class ReedsBirdPair:

    
    
    def __init__(self, male_reedsbird, female_reedsbird, is_occupied):
        self.spe_name = female_reedsbird.getReedsBirdSpeName()
        self.male_reedsbird = male_reedsbird
        self.female_reedsbird = female_reedsbird
        self.is_occupied = is_occupied    
        self.Pair_Hatch_Prob = (male_reedsbird.getReedsBirdHatchProb() + female_reedsbird.getReedsBirdHatchProb()) / 2
        self.Pair_Breed_Prob = max(male_reedsbird.getTotalBreedingCap() , female_reedsbird.getTotalBreedingCap())
        self.Pair_CBase_Prob = (male_reedsbird.getBaseReedsBirdCDectProb() + female_reedsbird.getBaseReedsBirdCDectProb()) / 2
        self.Pair_SBase_Prob = (male_reedsbird.getBaseReedsBirdSDectProb() + female_reedsbird.getBaseReedsBirdSDectProb()) / 2
        self.Pair_STBase_Prob = (male_reedsbird.getBaseReedsBirdStayProb() + female_reedsbird.getBaseReedsBirdStayProb()) / 2
        self.Pair_CDect_Prob = max(self.male_reedsbird.getReedsBirdCDectProb(), self.female_reedsbird.getReedsBirdCDectProb())  
        self.Pair_SDect_Prob = max(self.male_reedsbird.getReedsBirdSDectProb(), self.female_reedsbird.getReedsBirdSDectProb()) 
        self.Pair_WDect_Prob = max(self.male_reedsbird.getReedsBirdWDectProb(), self.female_reedsbird.getReedsBirdWDectProb())
        self.Pair_Stay_Prob = max(self.male_reedsbird.getReedsBirdStayProb(), self.female_reedsbird.getReedsBirdStayProb())
        self.Pair_Life = (male_reedsbird.getReedsBirdLife() + female_reedsbird.getReedsBirdLife()) / 2
        self.Pair_d_Col = (male_reedsbird.getReedsBirdCDectReinFac() + female_reedsbird.getReedsBirdCDectReinFac()) / 2
        self.Pair_d_Sha = (male_reedsbird.getReedsBirdSDectReinFac() + female_reedsbird.getReedsBirdSDectReinFac()) / 2
        self.Pair_d_Sta = (male_reedsbird.getReedsBirdStayReinFac() + female_reedsbird.getReedsBirdStayReinFac()) / 2
        self.Pair_d_Bre = (male_reedsbird.getReedsBirdBreedReinFac() + female_reedsbird.getReedsBirdBreedReinFac()) / 2
        self.Pair_BaseBreed_Prob = (male_reedsbird.getReedsBirdBreedProb() + female_reedsbird.getReedsBirdBreedProb()) / 2
        self.Egg_Num = self.getFemaleReedsBirdinPair().getReedsBirdEggNum()
        self.Pcoef_1 = (male_reedsbird.getReedsBirdBDecayCoef() + female_reedsbird.getReedsBirdBDecayCoef()) / 2
        self.Pcoef_2 = (male_reedsbird.getReedsBirdCDecayCoef() + female_reedsbird.getReedsBirdCDecayCoef()) / 2
        self.Pcoef_3 = (male_reedsbird.getReedsBirdSDecayCoef() + female_reedsbird.getReedsBirdSDecayCoef()) / 2
        self.Pcoef_4 = (male_reedsbird.getReedsBirdWDecayCoef() + female_reedsbird.getReedsBirdWDecayCoef()) / 2
        self.sigma1 = 0.1
        self.sigma2 = 1
        self.l_low = 0
        self.l_high = 4
        self.temp_val = 0
    
    def passReedsBirdGroupCoef(self, l1, l2, sig1, sig2):
        self.l_low = l1
        self.l_high = l2
        self.sigma1 = sig1
        self.sigma2 = sig2
    
    def getReedsBirdPairCDectProb(self):
        return self.Pair_CDect_Prob
    
    def getReedsBirdPairSDectProb(self):
        return self.Pair_SDect_Prob
    
    def getReedsBirdPairWDectProb(self):
        return self.Pair_WDect_Prob
        
    def getReedsBirdPairStayProb(self):
        return self.Pair_Stay_Prob 
    
    def getMaleReedsBirdinPair(self):
        return self.male_reedsbird
    
    def getFemaleReedsBirdinPair(self):
        return self.female_reedsbird
    
    def getNestOccupyCond(self):
        return self.is_occupied
    
    def getReedsBirdPairReinDectProb(self):
        return (self.male_reedsbird.getTotalReedsBirdReinFac() + self.female_reedsbird.getTotalReedsBirdReinFac())/2
    
    def getReedsBirdPairTheoBreedCap(self):
        return self.Pair_BaseBreed_Prob
    
    def getReedsBirdPairRealBreedCap(self):
        return self.Pair_Breed_Prob
    
    def setMaleReedsBirdinPair(self, male):
        self.male_reedsbird = male
    
    def setFemaleReedsBirdinPair(self, female):
        self.female_reedsbird = female
    
    def setNestOccupyCond(self, o_status):
        self.is_occupied = o_status
    
    def reCalReedsBirdDectProb(self, penalty_value):
        pass
    
    def calReedsBirdPairCDectProb(self):
        self.Pair_CDect_Prob = max(self.male_reedsbird.getReedsBirdCDectProb(), self.female_reedsbird.getReedsBirdCDectProb())
        
    def calReedsBirdPairSDectProb(self):
        self.Pair_SDect_Prob = max(self.male_reedsbird.getReedsBirdSDectProb(), self.female_reedsbird.getReedsBirdSDectProb())
    
    def LearnReedsBirdDectProbFromPair(self):
        PC = max(self.male_reedsbird.getReedsBirdCDectProb(), self.female_reedsbird.getReedsBirdCDectProb())
        self.male_reedsbird.setReedsBirdCDectProb(PC)
        self.female_reedsbird.setReedsBirdCDectProb(PC)
        PS = max(self.male_reedsbird.getReedsBirdSDectProb(), self.female_reedsbird.getReedsBirdSDectProb())
        self.male_reedsbird.setReedsBirdSDectProb(PS)
        self.female_reedsbird.setReedsBirdSDectProb(PS)
        
    def isReedsBirdPairRuined(self):
        if self.female_reedsbird.isReedsBirdDead() or self.male_reedsbird.isReedsBirdDead():
            return True
        else:
            return False
    
    def updateCrowdBreedPenalty(self, penalty_value):
        self.Pair_Breed_Prob = self.Pair_Breed_Prob / penalty_value
        # if penalty_value > 4:
        #     self.Pair_Breed_Prob = self.Pair_Breed_Prob / (6 * penalty_value)
        # elif penalty_value > 2:
        #     self.Pair_Breed_Prob = self.Pair_Breed_Prob / (4 * penalty_value)
        # elif penalty_value > 1:
        #     self.Pair_Breed_Prob = self.Pair_Breed_Prob / (penalty_value + 3.5)
        # elif penalty_value > 0.75:
        #     self.Pair_Breed_Prob = self.Pair_Breed_Prob / (penalty_value + 1.5) 
        # elif penalty_value > 0:
        #     self.Pair_Breed_Prob = self.Pair_Breed_Prob / (penalty_value + 1) 
        # self.temp_val = self.Pair_Breed_Prob
    
    def growReedsBirdinPair(self):
        self.female_reedsbird.growReedsBird()
        self.male_reedsbird.growReedsBird()
        
    def ReedsBridPairBreedLearning(self):
        self.female_reedsbird.updateTotalBreedingCap()
        self.male_reedsbird.updateTotalBreedingCap()
        self.Pair_Breed_Prob = max(self.male_reedsbird.getReedsBirdBreedProb() , self.female_reedsbird.getReedsBirdBreedProb())

class OccupiedReedsBirdPair(ReedsBirdPair):
# coef_1, coef_2, coef_3, coef_4, prob, prob_b, prob_c1, prob_c0, prob_s1, prob_s0, life, age, dpc, dps, dpb, dpn, N    

    def __init__(self, male_reedsbird, female_reedsbird, is_occupied, cuckooEgg):
        super(OccupiedReedsBirdPair,self).__init__(male_reedsbird, female_reedsbird, is_occupied)  
        self.cuckooEgg = cuckooEgg
    
    def getOccupiedCuckooEgg(self):
        return self.cuckooEgg
    
    def setOccupiedCuckooEgg(self, cuckooEgg):
        self.cuckooEgg = cuckooEgg
        
    def OccupiedCucWinOperation(self):
        female_probc = self.female_reedsbird.getReedsBirdCDectProb() + self.female_reedsbird.getReedsBirdCDectReinFac()
        self.female_reedsbird.setReedsBirdCDectProb(female_probc)
        female_probs = self.female_reedsbird.getReedsBirdSDectProb() + self.female_reedsbird.getReedsBirdSDectReinFac()
        self.female_reedsbird.setReedsBirdCDectProb(female_probs)
        
        male_probc = self.male_reedsbird.getReedsBirdCDectProb() + self.male_reedsbird.getReedsBirdCDectReinFac()
        self.male_reedsbird.setReedsBirdCDectProb(male_probc)
        male_probs = self.male_reedsbird.getReedsBirdSDectProb() + self.male_reedsbird.getReedsBirdSDectReinFac()
        self.male_reedsbird.setReedsBirdSDectProb(male_probs)
        
        self.LearnReedsBirdDectProbFromPair()
        
                
    def OccupiedReeWinOperation(self):
        Baby_Male_ReedsBird = []
        Baby_Female_ReedsBird = []
        Actual_Egg_Num = self.Egg_Num - 1
        Hatch_Prob = self.getFemaleReedsBirdinPair().getReedsBirdHatchProb()
        Breed_Prob = self.getReedsBirdPairRealBreedCap()
        # print("Prob of breed here is %f, %f"%(self.Pair_Breed_Prob,self.temp_val))
        for i in range(Actual_Egg_Num):
            if IsReallyWrongDetect(self.getReedsBirdPairWDectProb()):
                continue
            if IsReallyHatched(Hatch_Prob) and IsReallyAlive(Breed_Prob):
                life = round(genWeibullSampleValue(self.Pair_Life, self.sigma2, self.l_low, self.l_high))
                age = 0
                
                p_1 =  genNormalSampleValue(self.Pcoef_1, self.sigma1, 0.995 * self.Pcoef_1, min(self.Pcoef_1 * 1.005, 2))
                p_2 =  genNormalSampleValue(self.Pcoef_2, self.sigma1, 0.995 * self.Pcoef_2, min(self.Pcoef_2 * 1.005, 2))
                p_3 =  genNormalSampleValue(self.Pcoef_3, self.sigma1, 0.995 * self.Pcoef_3, min(self.Pcoef_3 * 1.005, 2))
                p_4 =  genNormalSampleValue(self.Pcoef_4, self.sigma1, 0.995 * self.Pcoef_4, min(self.Pcoef_4 * 1.005, 2))
                p_h_p = genNormalSampleValue(self.Pair_Hatch_Prob, self.sigma1, 0, 1)
                p_b_p = genNormalSampleValue(self.Pair_BaseBreed_Prob, self.sigma1, 0, 1)
                p_c_p = genNormalSampleValue(self.Pair_CBase_Prob, self.sigma1, 0, min(1, 2 * self.Pair_CBase_Prob))
                p_s_p = genNormalSampleValue(self.Pair_SBase_Prob, self.sigma1, 0, min(1, 2 * self.Pair_SBase_Prob))
                p_st_p = genNormalSampleValue(self.Pair_STBase_Prob, self.sigma1, 0, min(1, 2 * self.Pair_STBase_Prob))
                d_p_c_p = genNormalSampleValue(self.Pair_d_Col, self.sigma1, 0.9 * self.Pair_d_Col, 1.1 * self.Pair_d_Col)
                d_p_s_p = genNormalSampleValue(self.Pair_d_Sha, self.sigma1, 0.9 * self.Pair_d_Sha, 1.1 * self.Pair_d_Sha)
                d_p_b_p = genNormalSampleValue(self.Pair_d_Bre, self.sigma1, 0.9 * self.Pair_d_Bre, 1.1 * self.Pair_d_Bre)
                d_p_st_p = genNormalSampleValue(self.Pair_d_Sta, self.sigma1, 0.9 * self.Pair_d_Sta, 1.1 * self.Pair_d_Sta)
                r_e_n = round(genNormalSampleValue(self.Egg_Num, self.sigma2, round(self.Egg_Num / 2), round(1.5 * self.Egg_Num)))
                if IsFemaleBaby(0.5):
                    Baby_Female_ReedsBird.append(FemaleReedsBird(self.spe_name, p_1, p_2, p_3, p_4, p_h_p, p_b_p, p_b_p, \
                                                                 p_c_p, p_c_p, p_s_p, p_s_p, p_st_p, p_st_p, life, age,\
                                                                 d_p_c_p, d_p_s_p, d_p_b_p, d_p_st_p, r_e_n))
                else:
                    Baby_Male_ReedsBird.append(MaleReedsBird(self.spe_name, p_1, p_2, p_3, p_4, p_h_p, p_b_p, p_b_p, \
                                                                 p_c_p, p_c_p, p_s_p, p_s_p, p_st_p, p_st_p, life, age,\
                                                                 d_p_c_p, d_p_s_p, d_p_b_p, d_p_st_p))
        return Baby_Male_ReedsBird, Baby_Female_ReedsBird
        
    def OccupiedCucDeadEggOperation(self):
        Baby_Male_ReedsBird = []
        Baby_Female_ReedsBird = []
        Actual_Egg_Num = self.Egg_Num - 1
        Hatch_Prob = self.getFemaleReedsBirdinPair().getReedsBirdHatchProb()
        Breed_Prob = self.getReedsBirdPairRealBreedCap()
        for i in range(Actual_Egg_Num):
            if IsReallyWrongDetect(self.getReedsBirdPairWDectProb()):
                continue
            if IsReallyHatched(Hatch_Prob) and IsReallyAlive(Breed_Prob):
                life = round(genWeibullSampleValue(self.Pair_Life, self.sigma2, self.l_low, self.l_high))
                age = 0
                p_1 =  genNormalSampleValue(self.Pcoef_1, self.sigma1, 0.995 * self.Pcoef_1, min(self.Pcoef_1 * 1.005, 2))
                p_2 =  genNormalSampleValue(self.Pcoef_2, self.sigma1, 0.995 * self.Pcoef_2, min(self.Pcoef_2 * 1.005, 2))
                p_3 =  genNormalSampleValue(self.Pcoef_3, self.sigma1, 0.995 * self.Pcoef_3, min(self.Pcoef_3 * 1.005, 2))
                p_4 =  genNormalSampleValue(self.Pcoef_4, self.sigma1, 0.995 * self.Pcoef_4, min(self.Pcoef_4 * 1.005, 2))
                p_h_p = genNormalSampleValue(self.Pair_Hatch_Prob, self.sigma1, 0, 1)
                p_b_p = genNormalSampleValue(self.Pair_BaseBreed_Prob, self.sigma1, 0, 1)
                p_c_p = genNormalSampleValue(max(self.Pair_CBase_Prob - self.Pcoef_2, 0), self.sigma1, 0, min(1, 2 * self.Pair_CBase_Prob))
                p_s_p = genNormalSampleValue(max(self.Pair_SBase_Prob - self.Pcoef_3, 0), self.sigma1, 0, min(1, 2 * self.Pair_SBase_Prob))
                p_st_p = genNormalSampleValue(self.Pair_STBase_Prob, self.sigma1, 0, min(1, 2 * self.Pair_STBase_Prob))
                d_p_c_p = genNormalSampleValue(self.Pair_d_Col, self.sigma1, 0.9 * self.Pair_d_Col, 1.1 * self.Pair_d_Col)
                d_p_s_p = genNormalSampleValue(self.Pair_d_Sha, self.sigma1, 0.9 * self.Pair_d_Sha, 1.1 * self.Pair_d_Sha)
                d_p_b_p = genNormalSampleValue(self.Pair_d_Bre, self.sigma1, 0.9 * self.Pair_d_Bre, 1.1 * self.Pair_d_Bre)
                d_p_st_p = genNormalSampleValue(self.Pair_d_Sta, self.sigma1, 0.9 * self.Pair_d_Sta, 1.1 * self.Pair_d_Sta)
                r_e_n = round(genNormalSampleValue(self.Egg_Num, self.sigma2, round(self.Egg_Num / 2), round(1.5 * self.Egg_Num)))
                if IsFemaleBaby(0.5):
                    Baby_Female_ReedsBird.append(FemaleReedsBird(self.spe_name, p_1, p_2, p_3, p_4, p_h_p, p_b_p, p_b_p, \
                                                                 p_c_p, p_c_p, p_s_p, p_s_p, p_st_p, p_st_p, life, age,\
                                                                 d_p_c_p, d_p_s_p, d_p_b_p, d_p_st_p, r_e_n))
                else:
                    Baby_Male_ReedsBird.append(MaleReedsBird(self.spe_name, p_1, p_2, p_3, p_4, p_h_p, p_b_p, p_b_p, \
                                                                 p_c_p, p_c_p, p_s_p, p_s_p, p_st_p, p_st_p, life, age,\
                                                                 d_p_c_p, d_p_s_p, d_p_b_p, d_p_st_p))
        return Baby_Male_ReedsBird, Baby_Female_ReedsBird
        
        
class NonOccupiedReedsBirdPair(ReedsBirdPair):
    def NonOccupiedOperation(self):
        Baby_Male_ReedsBird = []
        Baby_Female_ReedsBird = []
        Hatch_Prob = self.getFemaleReedsBirdinPair().getReedsBirdHatchProb()
        Breed_Prob = self.getReedsBirdPairRealBreedCap()
        for i in range(self.Egg_Num):
            if IsReallyWrongDetect(self.getReedsBirdPairWDectProb()):
                continue
            if IsReallyHatched(Hatch_Prob) and IsReallyAlive(Breed_Prob):
                life = round(genWeibullSampleValue(self.Pair_Life, self.sigma2, self.l_low, self.l_high))
                age = 0
                p_1 =  genNormalSampleValue(self.Pcoef_1, self.sigma1, 0.995 * self.Pcoef_1, min(self.Pcoef_1 * 1.005, 2))
                p_2 =  genNormalSampleValue(self.Pcoef_2, self.sigma1, 0.995 * self.Pcoef_2, min(self.Pcoef_2 * 1.005, 2))
                p_3 =  genNormalSampleValue(self.Pcoef_3, self.sigma1, 0.995 * self.Pcoef_3, min(self.Pcoef_3 * 1.005, 2))
                p_4 =  genNormalSampleValue(self.Pcoef_4, self.sigma1, 0.995 * self.Pcoef_4, min(self.Pcoef_4 * 1.005, 2))
                p_h_p = genNormalSampleValue(self.Pair_Hatch_Prob, self.sigma1, 0, 1)
                p_b_p = genNormalSampleValue(self.Pair_BaseBreed_Prob, self.sigma1, 0, 1)
                p_c_p = genNormalSampleValue(max(self.Pair_CBase_Prob - self.Pcoef_2, 0), self.sigma1, 0, min(1, 2 * self.Pair_CBase_Prob))
                p_s_p = genNormalSampleValue(max(self.Pair_SBase_Prob - self.Pcoef_3, 0), self.sigma1, 0, min(1, 2 * self.Pair_SBase_Prob))
                p_st_p = genNormalSampleValue(self.Pair_STBase_Prob, self.sigma1, 0, min(1, 2 * self.Pair_STBase_Prob))
                d_p_c_p = genNormalSampleValue(self.Pair_d_Col, self.sigma1, 0.9 * self.Pair_d_Col, 1.1 * self.Pair_d_Col)
                d_p_s_p = genNormalSampleValue(self.Pair_d_Sha, self.sigma1, 0.9 * self.Pair_d_Sha, 1.1 * self.Pair_d_Sha)
                d_p_b_p = genNormalSampleValue(self.Pair_d_Bre, self.sigma1, 0.9 * self.Pair_d_Bre, 1.1 * self.Pair_d_Bre)
                d_p_st_p = genNormalSampleValue(self.Pair_d_Sta, self.sigma1, 0.9 * self.Pair_d_Sta, 1.1 * self.Pair_d_Sta)
                r_e_n = round(genNormalSampleValue(self.Egg_Num, self.sigma2, round(self.Egg_Num / 2), round(1.5 * self.Egg_Num)))
                if IsFemaleBaby(0.5):
                    Baby_Female_ReedsBird.append(FemaleReedsBird(self.spe_name, p_1, p_2, p_3, p_4, p_h_p, p_b_p, p_b_p, \
                                                                 p_c_p, p_c_p, p_s_p, p_s_p, p_st_p, p_st_p, life, age,\
                                                                 d_p_c_p, d_p_s_p, d_p_b_p, d_p_st_p, r_e_n))
                else:
                    Baby_Male_ReedsBird.append(MaleReedsBird(self.spe_name, p_1, p_2, p_3, p_4, p_h_p, p_b_p, p_b_p, \
                                                                 p_c_p, p_c_p, p_s_p, p_s_p, p_st_p, p_st_p, life, age,\
                                                                 d_p_c_p, d_p_s_p, d_p_b_p, d_p_st_p))
        return Baby_Male_ReedsBird, Baby_Female_ReedsBird
    


   
    
    