from ReedsBird import *
from ReedsBirdPair import *
from ReedsBirdGroup import *
import random

class ReedsBirdGroups:
    ReedsBirds = {}
    def __init__(self, ReedsBirds):
        self.ReedsBirds = ReedsBirds
    
    def modifyReedsBirdsSpe(self, spe, reedsbird):
        self.ReedsBirds[spe] = reedsbird
    
    def delReedsBirdsSpe(self, spe):
        if spe in self.ReedsBirds:
            self.ReedsBirds.pop(spe)
            
    def getReedsBirds(self):
        return self.ReedsBirds
    
    def setReedsBirds(self, reed_dict):
        self.ReedsBirds = reed_dict
        
    def selectrandomkey(self):
        return random.sample(self.ReedsBirds.keys(), 1)[0]
           
    
    def getReedsBirdSpeNum(self):
        count = 0
        for k in self.ReedsBirds:
            count = count + 1
        return count
    
    def DelExtinctReedsBirds(self):
        for k in self.ReedsBirds:
            if self.ReedsBirds.get(k).getTotalReedsBirdNum() == 0:
                self.ReedsBirds.pop(k)
                
    def getAvgReedsBirdPopSize(self):
        reeds_sum = 0
        for key in self.ReedsBirds.keys():
            reeds_sum += self.ReedsBirds.get(key).get('POP_N')
        return reeds_sum/len(self.ReedsBirds)
    
    # def AllReedsFirstGaming(self):
    #     for r in self.ReedsBirds.keys():
    #         r.ReedsBirdFirstGaming()
        