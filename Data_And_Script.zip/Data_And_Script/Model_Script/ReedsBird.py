class ReedsBird:
    # is_single: if the ReedsBird is single or not
    # prob    prob of hatching
    # prob_b: prob of successfully breeding.
    # prob_c1: prob of detecting cheating (color)
    # prob_c0: prob of detecting that can be inherited (color)
    # prob_s1: prob of detecting cheating (shape)
    # prob_s0: prob of detecting that can be inherited (shape)
    
    # dpc: reinforcement from last-year cheating (color)
    # dps: reinforcement from last-year cheating (shape)
    # dpb: Increase of breeding capacity due to previous experience
    # dpn: the increase of prob to staying at nest in second year. [Thought, breed rate should be something negative to dps]
    
    def __init__(self, spe_name, coef_1, coef_2, coef_3, coef_4, prob, total_prob_b, prob_b, prob_c1, prob_c0, prob_s1, prob_s0, \
                 prob_st, prob_st0,life, age, dpc, dps, dpb, dpn):
        self.spe_name = spe_name
        self.coef_1 = coef_1
        self.coef_2 = coef_2
        self.coef_3 = coef_3
        self.coef_4 = coef_4        
        self.prob = prob
        self.prob_b = prob_b
        self.prob_c1 = prob_c1
        self.prob_c0 = prob_c0
        self.prob_s1 = prob_s1
        self.prob_s0 = prob_s0
        self.prob_st = prob_st
        self.prob_st0 = prob_st0
        self.life = life
        self.age = age
        self.dpc = dpc
        self.dps = dps
        self.dpb = dpb
        self.dpn = dpn
        self.total_prob_b = total_prob_b
    
    def setReedsBirdSpeName(self, name):
        self.spe_name = name
    
    def getReedsBirdSpeName(self):
        return self.spe_name
    
    def setReedsBirdBDecayCoef(self, val):
        self.coef_1 = val
        
    def getReedsBirdBDecayCoef(self):
        return self.coef_1
    
    def setReedsBirdCDecayCoef(self, val):
        self.coef_2 = val
        
    def getReedsBirdCDecayCoef(self):
        return self.coef_2
    
    def setReedsBirdSDecayCoef(self, val):
        self.coef_3 = val
        
    def getReedsBirdSDecayCoef(self):
        return self.coef_3
    
    def setReedsBirdWDecayCoef(self, val):
        self.coef_4 = val
    
    def getReedsBirdWDecayCoef(self):
        return self.coef_4
    
    def setReedsBirdHatchProb(self, p1):
        self.prob = p1
        
    def getReedsBirdHatchProb(self):
        return self.prob
    
    def setReedsBirdBreedProb(self, p1):
        self.prob_b = p1
        
    def getReedsBirdBreedProb(self):
        return self.prob_b
    
    def setReedsBirdCDectProb(self, val):
        self.prob_c1 = val
    
    def getReedsBirdCDectProb(self):
        return self.prob_c1
    
    def setBaseReedsBirdCDectProb(self, val):
        self.prob_c0 = val
    
    def getBaseReedsBirdCDectProb(self):
        return self.prob_c0
    
    def setReedsBirdSDectProb(self, val):
        self.prob_s1 = val
    
    def getReedsBirdSDectProb(self):
        return self.prob_s1
    
    def setBaseReedsBirdSDectProb(self, val):
        self.prob_s0 = val
    
    def getBaseReedsBirdSDectProb(self):
        return self.prob_s0
    
    def setReedsBirdStayProb(self, val):
        self.prob_st = val
        
    def getReedsBirdStayProb(self):
        return self.prob_st
    
    def setBaseReedsBirdStayProb(self, val):
        self.prob_st0 = val
        
    def getBaseReedsBirdStayProb(self):
        return self.prob_st0
    
    def setReedsBirdLife(self, val):
        self.life = val
    
    def getReedsBirdLife(self):
        return self.life
    
    def setReedsBirdAge(self, val):
        self.age = val
    
    def getReedsBirdAge(self):
        return self.age 
    
    def setReedsBirdCDectReinFac(self, dp):
        self.dpc = dp
    
    def getReedsBirdCDectReinFac(self):
        return self.dpc
    
    def setReedsBirdSDectReinFac(self, dp):
        self.dps = dp
    
    def getReedsBirdSDectReinFac(self):
        return self.dps
    
    def setReedsBirdBreedReinFac(self, dp):
        self.dpb = dp
        
    def getReedsBirdBreedReinFac(self):
        return self.dpb
    
    def setReedsBirdStayReinFac(self, dp):
        self.dpn = dp
        
    def getReedsBirdStayReinFac(self):
        return self.dpn  
    
    def getReedsBirdRemYrs(self):
        return self.life - self.age       
    
    def getTotalBreedingCap(self):
        return self.total_prob_b
    
    def setTotalBreedingCap(self, val):
        self.total_prob_b = val
    
    def getReedsBirdWDectProb(self):
        return self.coef_4 * (self.total_prob_b) ** 2
    
    def reCalBreedingProb(self):
        self.total_prob_b = self.total_prob_b * (1 - self.coef_1) 
    
    def updateTotalBreedingCap(self):
        self.total_prob_b = self.total_prob_b + self.dpb
    
    def updateStayProb(self):
        self.prob_st = self.prob_st + self.dpn
    
    def isReedsBirdDead(self):
        if self.getReedsBirdRemYrs() > 0:
            return False
        else:
            return True
    
    def growReedsBird(self):
        self.age = self.age + 1
    
    def UpdateSecReedsBirdDectProb(self):
        self.prob_1 = min(self.prob_1 + self.dp1, 1)    
   
    def printReedsBird(self):
        print('==============================   It is a male reedsbird   =====================================\n')
        print('Age of this cuckoo is: %d, Lifetime of this cuckoo is: %d.\n'%(self.age,self.life))
        print('Current probability to detect cheating is %f. \n'%self.prob_1)

class FemaleReedsBird(ReedsBird):
    # N: number of eggs
    def __init__(self, spe_name, coef_1, coef_2, coef_3, coef_4, prob, total_prob_b, prob_b, prob_c1, prob_c0,\
                 prob_s1, prob_s0, prob_st, prob_st0, life, age, dpc, dps, dpb, dpn, N):
        super(FemaleReedsBird,self).__init__(spe_name, coef_1, coef_2, coef_3, coef_4, prob, total_prob_b, prob_b,\
                                             prob_c1, prob_c0, prob_s1, prob_s0, prob_st, prob_st0, life, age, dpc, dps, dpb, dpn)       
        self.N = N
    
    def getReedsBirdEggNum(self):
        return self.N
    
    def setReedsBirdEggNum(self, N0):
        self.N = N0
    
    def printReedsBird(self):
        print('==============================   It is a female reedsbird   =====================================\n')
        print('Age of this cuckoo is: %d, Lifetime of this cuckoo is: %d.\n'%(self.age,self.life))
        print('Current probability to detect cheating is %f. Number of eggs laid is %d. \n'%(self.prob_1,self.N))
   
class MaleReedsBird(ReedsBird):
    pass