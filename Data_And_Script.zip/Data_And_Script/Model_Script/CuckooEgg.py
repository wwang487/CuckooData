from ParasiteRand import *
from Cuckoo import *
class CuckooEgg:
        
    # spe_name, prob, life, age, prob_1, dp1, PCR_c, PCR_s, N, is_Preg, def_mom
    
    def __init__(self, female_cuckoo, male_cuckoo):
        self.female_cuckoo = female_cuckoo
        self.male_cuckoo = male_cuckoo
        self.spe_name = female_cuckoo.getCuckooSpeName()
        self.hatching = (female_cuckoo.getCuckooHatchProb() + male_cuckoo.getCuckooHatchProb()) / 2
        self.laying = female_cuckoo.getCuckooBaseLaidProb()
        self.life = (female_cuckoo.getCuckooLife() + male_cuckoo.getCuckooLife()) / 2
        self.PCR_c = female_cuckoo.getTotalCuckooColorReinFac()
        self.PCR_s = female_cuckoo.getTotalCuckooShapeReinFac()
        self.dp1 = female_cuckoo.getCuckooLaidReinFac()
        self.N = female_cuckoo.getCuckooEggNum()
        self.mom = female_cuckoo.getdefaultmom()
        self.life_cl = 0
        self.life_cr = 10
        self.sigma_1 = 0.1
        self.sigma_2 = 1
    
    def passCuckooGroupCoef(self, life_cl, life_cr, sigma_1, sigma_2):
        self.life_cl = life_cl
        self.life_cr = life_cr
        self.sigma_1 = sigma_1
        self.sigma_2 = sigma_2
    
    def UpdateDefaultMom(self, m):
        self.mom = m
    
    def HatchFemaleEgg(self):
        spe_name = self.spe_name
        prob = genNormalSampleValue(self.hatching, self.sigma_1, 0, 1)       
        age = 0
        prob_1 = genNormalSampleValue(self.laying, self.sigma_1, 0, 1) 
        PCR_c = self.PCR_c
        PCR_s = self.PCR_s
        
        PCR_c[self.mom] = genNormalSampleValue(self.PCR_c.get(self.mom), self.sigma_1, 0, 2 * self.PCR_c.get(self.mom))
        PCR_s[self.mom] = genNormalSampleValue(self.PCR_s.get(self.mom), self.sigma_1, 0, 2 * self.PCR_s.get(self.mom))
        life_C = round(genWeibullSampleValue(self.life, self.sigma_2, self.life_cl, self.life_cr))
        dp1 = genNormalSampleValue(self.dp1, self.sigma_1 / 10, 0.9 * self.dp1, 1.1 * self.dp1)
        N = round(genNormalSampleValue(self.N, self.sigma_2, round(self.N / 2), round(1.5 * self.N)))
        is_Preg = False
        mom = self.mom
        return spe_name, prob, life_C, age, prob_1, dp1, PCR_c, PCR_s, N, is_Preg, mom
    
    def HatchMaleEgg(self):
        spe_name = self.spe_name
        prob = self.hatching
        life_C = round(genWeibullSampleValue(self.life, self.sigma_2, self.life_cl, self.life_cr))
        age = 0
        return spe_name, prob, life_C, age
    
    def getCuckooEggHatchingProb(self):
        return self.hatching
    
    def getCuckooEggCCheatingReinFac(self):
        return self.PCR_c
    
    def getCuckooEggSCheatingReinFac(self):
        return self.PCR_s
    
    